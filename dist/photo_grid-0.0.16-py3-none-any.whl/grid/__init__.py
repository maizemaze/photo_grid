__author__ = "Chunpeng James Chen"
__version__ = "0.0.16"
__update__ = "Sep 12, 2019"
__all__ = ["CPU_Agent", "CPU_Field", "GPU_Anchor", "GPU_Cropper", "GPU_Input", "GPU_Kmeaner", "GPU_Output", "GRID", "Misc"]

"""
Update Log
- Sep 12, 2019 (0.0.15)
    * Fix problems wiht fixed segmentation
    * Organize file structure
    * Add dark mode
"""
